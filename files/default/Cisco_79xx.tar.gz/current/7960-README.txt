
Original files found on: http://www.loligo.com/asterisk/Cisco/79xx

This is the config examples for the Asterisk setup that I have.  I include
one "real" SIP phone with a bogus MAC address so you can see what it looks
like; you'll need to change the filename to be SIP[mac address].cnf to match
your gear.

Ringers were collected from various shareware and "open" tftp servers on the
Internet.  Use at your own risk.  

Note that the file P0S3-04-4-00.bin is BOGUS.  You will need to download the
REAL software from Cisco.  Note that the version numbers change; alter the
configs to suit the new numbers

Thanks to James for his "24" theme ringer.

Lots of changes to SIP code since this file was made, but no serious
modifications to functionality.  Current rev is 7.2, but I don't see any
reason that these configs wouldn't work with newer phones.

jtodd@loligo.com
2004-10-26
